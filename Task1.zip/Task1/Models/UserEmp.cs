﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Task1.Models
{
    public class UserEmp
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpAdress { get; set; }
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
